module.exports.GaugeValidation = require('./qdc/Gauge.validation');
/*define other in here*/
