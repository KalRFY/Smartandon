module.exports.GaugeController = require('./qdc/Gauge.controller');
module.exports.CommonController = require('./qdc/Common.controller');
/*define other in here*/