<template>
</template>
<style lang="scss" >
// Import Main styles for this application running standalone
@import '../standalone/styles/style';
</style>
<script>
export default {
    name: 'StandAloneStyle',
    data(props) {
        return {
        }
    },
    async created() {
    },
    setup() {
        return {
        }
    },
}
</script>